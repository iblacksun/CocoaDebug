//
//  Example
//  man
//
//  Created by man 11/11/2018.
//  Copyright © 2020 man. All rights reserved.
//

#import <UIKit/UIKit.h>

@class _FileInfo;

@interface _FilePreviewController : UIViewController

@property (nonatomic, strong) _FileInfo *fileInfo;

@end
