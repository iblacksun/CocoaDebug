//
//  Example
//  man
//
//  Created by man 11/11/2018.
//  Copyright © 2020 man. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface _DebugConsoleLabel : UILabel

- (void)updateLabelWithValue:(float)value;

- (NSAttributedString *)fpsAttributedStringWith:(float)fps;

@end
